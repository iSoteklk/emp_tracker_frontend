// Work Time Configuration
export interface WorkTimeConfig {
  // Standard work hours
  standardStartTime: string // Format: "HH:MM" (24-hour)
  standardEndTime: string // Format: "HH:MM" (24-hour)
  fullWorkingHours: number // Hours (e.g., 8 for 8 hours)

  // Break times
  lunchBreakDuration: number // Minutes
  shortBreakDuration: number // Minutes

  // Late threshold
  lateThresholdMinutes: number // Minutes after start time

  // Overtime calculation
  overtimeAfterHours: number // Hours after which overtime starts

  // Weekend configuration
  weekendDays: number[] // 0 = Sunday, 1 = Monday, etc.

  // Time format preferences
  use24HourFormat: boolean
  showSeconds: boolean
}

// API Response interfaces
interface WorkTimeConfigAPI {
  _id: string
  name: string
  standardStartTime: string
  standardEndTime: string
  fullWorkingHours: number
  lunchBreakDuration: number
  shortBreakDuration: number
  lateThresholdMinutes: number
  overtimeAfterHours: number
  weekendDays: number[]
  use24HourFormat: boolean
  showSeconds: boolean
  isActive: boolean
  createdAt: string
  updatedAt: string
  __v: number
}

interface WorkTimeConfigResponse {
  success: boolean
  data: WorkTimeConfigAPI[]
}

// Default configuration - Fallback if API fails
export const DEFAULT_WORK_CONFIG: WorkTimeConfig = {
  standardStartTime: "08:30", // 8:30 AM
  standardEndTime: "17:30", // 5:30 PM
  fullWorkingHours: 8, // 8 hours
  lunchBreakDuration: 60, // 1 hour lunch
  shortBreakDuration: 15, // 15 minutes break
  lateThresholdMinutes: 0, // Late if any time after start time
  overtimeAfterHours: 8, // Overtime after 8 hours
  weekendDays: [0, 6], // Sunday and Saturday
  use24HourFormat: true,
  showSeconds: true,
}

// Helper function to get auth token
function getAuthToken(): string | null {
  if (typeof window !== "undefined") {
    return localStorage.getItem("token")
  }
  return null
}

// Configuration management class
export class WorkTimeConfigManager {
  private static instance: WorkTimeConfigManager
  private config: WorkTimeConfig
  private isLoading = false
  private lastFetchTime = 0
  private readonly CACHE_DURATION = 5 * 60 * 1000 // 5 minutes cache

  private constructor() {
    this.config = this.loadLocalConfig()
    // Fetch from API on initialization
    this.fetchConfigFromAPI()
  }

  public static getInstance(): WorkTimeConfigManager {
    if (!WorkTimeConfigManager.instance) {
      WorkTimeConfigManager.instance = new WorkTimeConfigManager()
    }
    return WorkTimeConfigManager.instance
  }

  private loadLocalConfig(): WorkTimeConfig {
    if (typeof window !== "undefined") {
      const savedConfig = localStorage.getItem("workTimeConfig")
      if (savedConfig) {
        try {
          return { ...DEFAULT_WORK_CONFIG, ...JSON.parse(savedConfig) }
        } catch (error) {
          console.error("Error loading work config:", error)
        }
      }
    }
    return DEFAULT_WORK_CONFIG
  }

  private async fetchConfigFromAPI(): Promise<void> {
    // Check if we should fetch (not loading and cache expired)
    const now = Date.now()
    if (this.isLoading || now - this.lastFetchTime < this.CACHE_DURATION) {
      return
    }

    this.isLoading = true

    try {
      console.log("Fetching work time config from API...")

      const token = getAuthToken()
      const headers: Record<string, string> = {
        "Content-Type": "application/json",
      }

      if (token) {
        headers.Authorization = `Bearer ${token}`
      }

      const response = await fetch("/api/work-time/config", {
        method: "GET",
        headers,
      })

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }

      const data: WorkTimeConfigResponse = await response.json()
      console.log("Work time config API response:", data)

      if (data.success && data.data && data.data.length > 0) {
        // Find the active configuration
        const activeConfig = data.data.find((config) => config.isActive === true)

        if (activeConfig) {
          console.log("Found active work time config:", activeConfig.name)

          // Map API response to our config interface
          const mappedConfig: WorkTimeConfig = {
            standardStartTime: activeConfig.standardStartTime,
            standardEndTime: activeConfig.standardEndTime,
            fullWorkingHours: activeConfig.fullWorkingHours,
            lunchBreakDuration: activeConfig.lunchBreakDuration,
            shortBreakDuration: activeConfig.shortBreakDuration,
            lateThresholdMinutes: activeConfig.lateThresholdMinutes,
            overtimeAfterHours: activeConfig.overtimeAfterHours,
            weekendDays: activeConfig.weekendDays,
            use24HourFormat: activeConfig.use24HourFormat,
            showSeconds: activeConfig.showSeconds,
          }

          this.config = mappedConfig
          this.saveLocalConfig()
          this.lastFetchTime = now

          console.log("Work time config updated successfully:", mappedConfig)
        } else {
          console.warn("No active work time configuration found, using default config")
        }
      } else {
        console.warn("Invalid API response format, using existing config")
      }
    } catch (error) {
      console.error("Failed to fetch work time config from API:", error)
      // Continue using existing config (either from localStorage or default)
    } finally {
      this.isLoading = false
    }
  }

  public async getConfig(forceRefresh = false): Promise<WorkTimeConfig> {
    if (forceRefresh || Date.now() - this.lastFetchTime > this.CACHE_DURATION) {
      await this.fetchConfigFromAPI()
    }
    return { ...this.config }
  }

  public getConfigSync(): WorkTimeConfig {
    return { ...this.config }
  }

  public updateConfig(newConfig: Partial<WorkTimeConfig>): void {
    this.config = { ...this.config, ...newConfig }
    this.saveLocalConfig()
  }

  private saveLocalConfig(): void {
    if (typeof window !== "undefined") {
      localStorage.setItem("workTimeConfig", JSON.stringify(this.config))
    }
  }

  public async refreshConfig(): Promise<WorkTimeConfig> {
    return this.getConfig(true)
  }

  // Helper methods
  public isLate(clockInTime: Date): boolean {
    const startTime = this.parseTime(this.config.standardStartTime)
    const clockIn = {
      hours: clockInTime.getHours(),
      minutes: clockInTime.getMinutes(),
    }

    const startMinutes = startTime.hours * 60 + startTime.minutes
    const clockInMinutes = clockIn.hours * 60 + clockIn.minutes

    return clockInMinutes > startMinutes + this.config.lateThresholdMinutes
  }

  public isOvertime(workedHours: number): boolean {
    return workedHours > this.config.overtimeAfterHours
  }

  public isWeekend(date: Date): boolean {
    return this.config.weekendDays.includes(date.getDay())
  }

  public calculateExpectedEndTime(startTime: Date): Date {
    const endTime = new Date(startTime)
    const workHours = this.config.fullWorkingHours
    const lunchBreakHours = this.config.lunchBreakDuration / 60

    endTime.setHours(endTime.getHours() + workHours)
    endTime.setMinutes(endTime.getMinutes() + this.config.lunchBreakDuration)

    return endTime
  }

  public formatTime(date: Date): string {
    const options: Intl.DateTimeFormatOptions = {
      hour: "2-digit",
      minute: "2-digit",
      hour12: !this.config.use24HourFormat,
    }

    if (this.config.showSeconds) {
      options.second = "2-digit"
    }

    return date.toLocaleTimeString(undefined, options)
  }

  public parseTime(timeString: string): { hours: number; minutes: number } {
    const [hours, minutes] = timeString.split(":").map(Number)
    return { hours, minutes }
  }

  public getWorkingHoursText(): string {
    const start = this.config.standardStartTime
    const end = this.config.standardEndTime
    return `${start} - ${end} (${this.config.fullWorkingHours}h)`
  }
}

// Export singleton instance
export const workTimeConfig = WorkTimeConfigManager.getInstance()
