import { type NextRequest, NextResponse } from "next/server"

const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || "http://localhost:4000"

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { id } = params
    const body = await request.json()
    console.log(`Updating work time config ${id}:`, body)

    const response = await fetch(`${API_BASE_URL}/api/v1/work-time/config/${id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(body),
    })

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}))
      throw new Error(`HTTP error! status: ${response.status}, message: ${errorData.message || "Unknown error"}`)
    }

    const data = await response.json()
    console.log("Work time config updated successfully")

    return NextResponse.json(data)
  } catch (error) {
    console.error("Error updating work time config:", error)
    return NextResponse.json({ success: false, error: "Failed to update work time configuration" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { id } = params
    console.log(`Deleting work time config ${id}`)

    const response = await fetch(`${API_BASE_URL}/api/v1/work-time/config/${id}`, {
      method: "DELETE",
      headers: {
        "Content-Type": "application/json",
      },
    })

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}))
      throw new Error(`HTTP error! status: ${response.status}, message: ${errorData.message || "Unknown error"}`)
    }

    const data = await response.json()
    console.log("Work time config deleted successfully")

    return NextResponse.json(data)
  } catch (error) {
    console.error("Error deleting work time config:", error)
    return NextResponse.json({ success: false, error: "Failed to delete work time configuration" }, { status: 500 })
  }
}