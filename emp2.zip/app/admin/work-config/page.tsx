"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { SidebarTrigger } from "@/components/ui/sidebar"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { AuthGuard } from "@/components/auth-guard"
import { Clock, Save, Plus, Edit, Trash2, LogOut, RefreshCw, CheckCircle, Circle } from "lucide-react"
import { workTimeConfig } from "@/lib/work-config"

interface WorkTimeConfigAPI {
  _id: string
  name: string
  standardStartTime: string
  standardEndTime: string
  fullWorkingHours: number
  lunchBreakDuration: number
  shortBreakDuration: number
  lateThresholdMinutes: number
  overtimeAfterHours: number
  weekendDays: number[]
  use24HourFormat: boolean
  showSeconds: boolean
  isActive: boolean
  createdAt: string
  updatedAt: string
}

interface WorkTimeConfigForm {
  name: string
  standardStartTime: string
  standardEndTime: string
  fullWorkingHours: number
  lunchBreakDuration: number
  shortBreakDuration: number
  lateThresholdMinutes: number
  overtimeAfterHours: number
  weekendDays: number[]
  use24HourFormat: boolean
  showSeconds: boolean
}

const initialFormData: WorkTimeConfigForm = {
  name: "",
  standardStartTime: "08:30",
  standardEndTime: "17:00",
  fullWorkingHours: 8,
  lunchBreakDuration: 30,
  shortBreakDuration: 15,
  lateThresholdMinutes: 5,
  overtimeAfterHours: 8,
  weekendDays: [0, 6],
  use24HourFormat: true,
  showSeconds: false,
}

function WorkConfigContent() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [configs, setConfigs] = useState<WorkTimeConfigAPI[]>([])
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [formData, setFormData] = useState<WorkTimeConfigForm>(initialFormData)
  const [showForm, setShowForm] = useState(false)

  const weekDayNames = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]

  useEffect(() => {
    const userData = localStorage.getItem("user")
    if (userData) {
      const parsedUser = JSON.parse(userData)
      setUser(parsedUser)

      if (parsedUser.role !== "admin") {
        router.push("/dashboard")
        return
      }
    }

    fetchConfigs()
  }, [router])

  const fetchConfigs = async () => {
    try {
      setLoading(true)
      const response = await fetch("/api/work-time/config")
      const data = await response.json()

      if (data.success && data.data) {
        setConfigs(data.data)
      }
    } catch (error) {
      console.error("Error fetching configs:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleLogout = () => {
    localStorage.removeItem("token")
    localStorage.removeItem("user")
    localStorage.removeItem("contact")
    localStorage.removeItem("userLocation")
    localStorage.removeItem("locationSkipped")
    window.dispatchEvent(new Event("auth-change"))
    router.push("/login")
  }

  const handleFormChange = (key: keyof WorkTimeConfigForm, value: any) => {
    setFormData((prev) => ({ ...prev, [key]: value }))
  }

  const handleWeekendToggle = (dayIndex: number) => {
    const newWeekendDays = formData.weekendDays.includes(dayIndex)
      ? formData.weekendDays.filter((d) => d !== dayIndex)
      : [...formData.weekendDays, dayIndex]
    handleFormChange("weekendDays", newWeekendDays)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!formData.name.trim()) {
      alert("Please enter a configuration name")
      return
    }

    try {
      setSaving(true)

      const url = editingId ? `/api/work-time/config/${editingId}` : "/api/work-time/config"

      const method = editingId ? "PUT" : "POST"

      const response = await fetch(url, {
        method,
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      })

      const result = await response.json()

      if (result.success) {
        await fetchConfigs()
        setShowForm(false)
        setEditingId(null)
        setFormData(initialFormData)

        // Refresh the work config cache
        await workTimeConfig.refreshConfig()
      } else {
        alert(result.error || "Failed to save configuration")
      }
    } catch (error) {
      console.error("Error saving config:", error)
      alert("Failed to save configuration")
    } finally {
      setSaving(false)
    }
  }

  const handleEdit = (config: WorkTimeConfigAPI) => {
    setFormData({
      name: config.name,
      standardStartTime: config.standardStartTime,
      standardEndTime: config.standardEndTime,
      fullWorkingHours: config.fullWorkingHours,
      lunchBreakDuration: config.lunchBreakDuration,
      shortBreakDuration: config.shortBreakDuration,
      lateThresholdMinutes: config.lateThresholdMinutes,
      overtimeAfterHours: config.overtimeAfterHours,
      weekendDays: config.weekendDays,
      use24HourFormat: config.use24HourFormat,
      showSeconds: config.showSeconds,
    })
    setEditingId(config._id)
    setShowForm(true)
  }

  const handleDelete = async (id: string) => {
    if (!confirm("Are you sure you want to delete this configuration?")) {
      return
    }

    try {
      const response = await fetch(`/api/work-time/config/${id}`, {
        method: "DELETE",
      })

      const result = await response.json()

      if (result.success) {
        await fetchConfigs()
        await workTimeConfig.refreshConfig()
      } else {
        alert(result.error || "Failed to delete configuration")
      }
    } catch (error) {
      console.error("Error deleting config:", error)
      alert("Failed to delete configuration")
    }
  }

  const handleActivate = async (id: string) => {
    const config = configs.find((c) => c._id === id)
    if (!config) return

    try {
      const response = await fetch(`/api/work-time/config/${id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ...config,
          isActive: true,
        }),
      })

      const result = await response.json()

      if (result.success) {
        await fetchConfigs()
        await workTimeConfig.refreshConfig()
      } else {
        alert(result.error || "Failed to activate configuration")
      }
    } catch (error) {
      console.error("Error activating config:", error)
      alert("Failed to activate configuration")
    }
  }

  const resetForm = () => {
    setFormData(initialFormData)
    setEditingId(null)
    setShowForm(false)
  }

  if (!user || user.role !== "admin") {
    return null
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-sky-50 to-blue-100">
      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <SidebarTrigger />
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-sky-600 bg-clip-text text-transparent">
                Work Time Configuration
              </h1>
              <p className="text-sm text-slate-600">Manage work schedules and time settings</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Button
              variant="outline"
              onClick={fetchConfigs}
              disabled={loading}
              className="flex items-center gap-2 bg-white/80 border-blue-200 text-blue-700 hover:bg-blue-50"
            >
              <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
              Refresh
            </Button>
            <Button
              variant="outline"
              onClick={handleLogout}
              className="flex items-center gap-2 bg-white/80 border-blue-200 text-blue-700 hover:bg-blue-50"
            >
              <LogOut className="h-4 w-4" />
              Logout
            </Button>
          </div>
        </div>

        {/* Existing Configurations */}
        <Card className="bg-white/80 border-blue-100 mb-6">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Existing Configurations
              </CardTitle>
              <Button onClick={() => setShowForm(true)} className="flex items-center gap-2">
                <Plus className="h-4 w-4" />
                Add New Config
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="text-center py-8">
                <RefreshCw className="h-8 w-8 animate-spin mx-auto mb-4 text-blue-600" />
                <p className="text-slate-600">Loading configurations...</p>
              </div>
            ) : configs.length === 0 ? (
              <div className="text-center py-8">
                <Clock className="h-12 w-12 mx-auto mb-4 text-slate-400" />
                <p className="text-slate-600">No configurations found</p>
              </div>
            ) : (
              <div className="grid gap-4">
                {configs.map((config) => (
                  <div
                    key={config._id}
                    className={`p-4 rounded-lg border-2 ${
                      config.isActive ? "border-green-200 bg-green-50" : "border-slate-200 bg-white"
                    }`}
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <h3 className="text-lg font-semibold">{config.name}</h3>
                        {config.isActive ? (
                          <Badge className="bg-green-100 text-green-800 border-green-200">
                            <CheckCircle className="h-3 w-3 mr-1" />
                            Active
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="text-slate-600">
                            <Circle className="h-3 w-3 mr-1" />
                            Inactive
                          </Badge>
                        )}
                      </div>
                      <div className="flex items-center gap-2">
                        {!config.isActive && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleActivate(config._id)}
                            className="text-green-600 border-green-200 hover:bg-green-50"
                          >
                            Activate
                          </Button>
                        )}
                        <Button size="sm" variant="outline" onClick={() => handleEdit(config)}>
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleDelete(config._id)}
                          className="text-red-600 border-red-200 hover:bg-red-50"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      <div>
                        <p className="text-slate-600">Work Hours</p>
                        <p className="font-medium">
                          {config.standardStartTime} - {config.standardEndTime}
                        </p>
                      </div>
                      <div>
                        <p className="text-slate-600">Full Hours</p>
                        <p className="font-medium">{config.fullWorkingHours}h</p>
                      </div>
                      <div>
                        <p className="text-slate-600">Lunch Break</p>
                        <p className="font-medium">{config.lunchBreakDuration}min</p>
                      </div>
                      <div>
                        <p className="text-slate-600">Late Threshold</p>
                        <p className="font-medium">{config.lateThresholdMinutes}min</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Configuration Form */}
        {showForm && (
          <Card className="bg-white/80 border-blue-100">
            <CardHeader>
              <CardTitle>{editingId ? "Edit Configuration" : "Add New Configuration"}</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Basic Info */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Basic Information</h3>
                  <div className="space-y-2">
                    <Label htmlFor="name">Configuration Name</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => handleFormChange("name", e.target.value)}
                      placeholder="e.g., Day Shift, Night Shift"
                      required
                    />
                  </div>
                </div>

                <Separator />

                {/* Work Hours */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Work Hours</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="startTime">Start Time</Label>
                      <Input
                        id="startTime"
                        type="time"
                        value={formData.standardStartTime}
                        onChange={(e) => handleFormChange("standardStartTime", e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="endTime">End Time</Label>
                      <Input
                        id="endTime"
                        type="time"
                        value={formData.standardEndTime}
                        onChange={(e) => handleFormChange("standardEndTime", e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="workingHours">Full Working Hours</Label>
                      <Input
                        id="workingHours"
                        type="number"
                        min="1"
                        max="24"
                        step="0.5"
                        value={formData.fullWorkingHours}
                        onChange={(e) => handleFormChange("fullWorkingHours", Number.parseFloat(e.target.value))}
                      />
                    </div>
                  </div>
                </div>

                <Separator />

                {/* Break Times */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Break Configuration</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="lunchBreak">Lunch Break (minutes)</Label>
                      <Input
                        id="lunchBreak"
                        type="number"
                        min="0"
                        max="120"
                        value={formData.lunchBreakDuration}
                        onChange={(e) => handleFormChange("lunchBreakDuration", Number.parseInt(e.target.value))}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="shortBreak">Short Break (minutes)</Label>
                      <Input
                        id="shortBreak"
                        type="number"
                        min="0"
                        max="60"
                        value={formData.shortBreakDuration}
                        onChange={(e) => handleFormChange("shortBreakDuration", Number.parseInt(e.target.value))}
                      />
                    </div>
                  </div>
                </div>

                <Separator />

                {/* Late and Overtime */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Late & Overtime Settings</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="lateThreshold">Late Threshold (minutes)</Label>
                      <Input
                        id="lateThreshold"
                        type="number"
                        min="0"
                        max="60"
                        value={formData.lateThresholdMinutes}
                        onChange={(e) => handleFormChange("lateThresholdMinutes", Number.parseInt(e.target.value))}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="overtimeAfter">Overtime After (hours)</Label>
                      <Input
                        id="overtimeAfter"
                        type="number"
                        min="1"
                        max="24"
                        step="0.5"
                        value={formData.overtimeAfterHours}
                        onChange={(e) => handleFormChange("overtimeAfterHours", Number.parseFloat(e.target.value))}
                      />
                    </div>
                  </div>
                </div>

                <Separator />

                {/* Weekend Days */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Weekend Days</h3>
                  <div className="flex flex-wrap gap-2">
                    {weekDayNames.map((day, index) => (
                      <Badge
                        key={index}
                        variant={formData.weekendDays.includes(index) ? "default" : "outline"}
                        className="cursor-pointer"
                        onClick={() => handleWeekendToggle(index)}
                      >
                        {day}
                      </Badge>
                    ))}
                  </div>
                </div>

                <Separator />

                {/* Display Settings */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Display Settings</h3>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label>24-Hour Format</Label>
                        <p className="text-sm text-muted-foreground">Use 24-hour time format</p>
                      </div>
                      <Switch
                        checked={formData.use24HourFormat}
                        onCheckedChange={(checked) => handleFormChange("use24HourFormat", checked)}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label>Show Seconds</Label>
                        <p className="text-sm text-muted-foreground">Display seconds in time</p>
                      </div>
                      <Switch
                        checked={formData.showSeconds}
                        onCheckedChange={(checked) => handleFormChange("showSeconds", checked)}
                      />
                    </div>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex gap-3 pt-4">
                  <Button type="submit" disabled={saving} className="flex items-center gap-2">
                    <Save className="h-4 w-4" />
                    {saving ? "Saving..." : "Save Configuration"}
                  </Button>
                  <Button type="button" variant="outline" onClick={resetForm}>
                    Cancel
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}

export default function WorkConfigPage() {
  return (
    <AuthGuard requiredRole="admin">
      <WorkConfigContent />
    </AuthGuard>
  )
}